package com.exp7.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.exp7.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

}