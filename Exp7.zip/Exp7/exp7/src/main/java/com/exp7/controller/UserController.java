package com.exp7.controller;

import org.springframework.web.bind.annotation.*;

import com.exp7.model.User;
import com.exp7.service.EmailService;
import com.exp7.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;
    private final EmailService emailService;

    public UserController(
            UserService userService,
            EmailService emailService) {
        this.userService = userService;
        this.emailService = emailService;
    }

    @PostMapping("/signup")
    public User signup(@RequestBody User user) {

        User savedUser = userService.registerUser(user);

        emailService.sendConfirmationEmail(
                savedUser.getEmail(),
                savedUser.getName()
        );
        savedUser.setPassword(null);

        return savedUser;
    }
}