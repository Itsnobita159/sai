package com.exp7.service;

import org.springframework.stereotype.Service;

import com.exp7.model.User;
import com.exp7.repository.UserRepository;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User registerUser(User user) {
        return userRepository.save(user);
    }
}