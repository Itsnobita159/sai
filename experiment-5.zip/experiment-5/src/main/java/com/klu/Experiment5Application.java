package com.klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Experiment5Application {

    public static void main(String[] args) {
        SpringApplication.run(Experiment5Application.class, args);
    }
}