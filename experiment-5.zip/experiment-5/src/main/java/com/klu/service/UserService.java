package com.klu.service;

import com.klu.entity.User;
import com.klu.repository.UserRepository;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository repo;

    public UserService(UserRepository repo) {
        this.repo = repo;
    }

    public String signup(User user) {

        if (user.getName() == null || user.getName().isEmpty()) {
            return "Name is required";
        }

        if (user.getEmail() == null || user.getEmail().isEmpty()) {
            return "Email is required";
        }

        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            return "Password is required";
        }

        if (repo.findByEmail(user.getEmail()).isPresent()) {
            return "Email already registered";
        }

        if (user.getRole() == null || user.getRole().isEmpty()) {
            user.setRole("USER");
        }

        repo.save(user);

        return "Signup successful";
    }

    public String signin(String email, String password) {

        User user = repo.findByEmail(email).orElse(null);

        if (user == null) {
            return "Invalid email";
        }

        if (!user.getPassword().equals(password)) {
            return "Invalid password";
        }

        return "Signin successful";
    }
}