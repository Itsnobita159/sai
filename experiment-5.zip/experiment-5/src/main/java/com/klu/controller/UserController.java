package com.klu.controller;

import com.klu.entity.User;
import com.klu.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService service;

    public UserController(UserService service) {
        this.service = service;
    }

    @PostMapping("/signup")
    public String signup(@RequestBody User user) {

        return service.signup(user);
    }

    @PostMapping("/signin")
    public String signin(@RequestBody Map<String, String> data) {

        String email = data.get("email");
        String password = data.get("password");

        return service.signin(email, password);
    }
}