package com.klu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
