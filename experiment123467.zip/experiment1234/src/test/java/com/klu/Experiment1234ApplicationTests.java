package com.klu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Experiment1234ApplicationTests {

	@Test
	void contextLoads() {
	}

}
