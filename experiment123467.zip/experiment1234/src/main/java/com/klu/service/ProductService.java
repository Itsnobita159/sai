package com.klu.service;

import com.klu.entity.Product;
import com.klu.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    // POST
    public Product addProduct(Product product) {
        return productRepository.save(product);
    }

    // GET all
    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    // GET by ID
    public Product getProduct(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
    }

    // PUT
    public Product updateProduct(Long id, Product product) {

        Product p = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        p.setProductName(product.getProductName());
        p.setCategory(product.getCategory());
        p.setDescription(product.getDescription());
        p.setPrice(product.getPrice());
        p.setStock(product.getStock());
        p.setImageUrl(product.getImageUrl());
        p.setRating(product.getRating());
        p.setStatus(product.getStatus());

        return productRepository.save(p);
    }

    // DELETE
    public void deleteProduct(Long id) {

        if (!productRepository.existsById(id)) {
            throw new RuntimeException("Product not found");
        }

        productRepository.deleteById(id);
    }
}