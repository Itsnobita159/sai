package com.klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Experiment1234Application {

	public static void main(String[] args) {
		SpringApplication.run(Experiment1234Application.class, args);
	}

}
